var time = 15;
function clock () {
	time --;
	if (time >= 0) {
		document.getElementById('seconds').innerHTML = time;
	} else {
		document.getElementById('seconds').innerHTML = 0;
		document.getElementById('button').innerHTML = '<button>GO TO LINK</button>';
	}
	setTimeout ("clock ()", 1000);
}
clock ();